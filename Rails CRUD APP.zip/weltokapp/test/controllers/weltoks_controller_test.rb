require 'test_helper'

class WeltoksControllerTest < ActionController::TestCase
  setup do
    @weltok = weltoks(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:weltoks)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create weltok" do
    assert_difference('Weltok.count') do
      post :create, weltok: {  }
    end

    assert_redirected_to weltok_path(assigns(:weltok))
  end

  test "should show weltok" do
    get :show, id: @weltok
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @weltok
    assert_response :success
  end

  test "should update weltok" do
    patch :update, id: @weltok, weltok: {  }
    assert_redirected_to weltok_path(assigns(:weltok))
  end

  test "should destroy weltok" do
    assert_difference('Weltok.count', -1) do
      delete :destroy, id: @weltok
    end

    assert_redirected_to weltoks_path
  end
end

require 'test_helper'

class WeltokTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

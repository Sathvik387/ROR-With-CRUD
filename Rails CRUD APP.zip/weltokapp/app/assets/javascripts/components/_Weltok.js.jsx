var Weltok = React.createClass({
    getInitialState() {
        return {editable: false}
    },
    handleEdit() {
        if(this.state.editable) {
            var title = this.refs.title.value;
            var id = this.props.weltok.id;
            var description = this.refs.description.value;
	    var author = this.refs.author.value;
	    var tags = this.refs.tags.value;
            var weltok = {id: id , title: title , description: description, author: author, tags: tags};
            this.props.handleUpdate(weltok);

        }
        this.setState({ editable: !this.state.editable })
    },

    render() {
        var title = this.state.editable ? <input type='text' ref='title' defaultValue={this.props.weltok.title} /> : <h3>{this.props.weltok.title}</h3>;
        var description = this.state.editable ? <input type='text' ref='description' defaultValue={this.props.weltok.description} />: <p>{this.props.weltok.description}</p>;
	var author = this.state.editable ? <input type='text' ref='author' defaultValue={this.props.weltok.author} />: <p>{this.props.weltok.author}</p>;
        var tags = this.state.editable ? <input type='text' ref='tags' defaultValue={this.props.weltok.tags} />: <p>{this.props.weltok.tags}</p>;
        return (
            <div>
                {title}
                {description}
		{author}
		{tags}
                <button onClick={this.props.handleDelete} >Delete</button>
                <button onClick={this.handleEdit}> {this.state.editable ? 'Submit' : 'Edit' } </button>
            </div>
        )
    }
});

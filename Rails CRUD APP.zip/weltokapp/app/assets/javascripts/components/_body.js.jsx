var Body = React.createClass({
    getInitialState() {
        return { weltoks: [] }
    },


    componentDidMount() {
        $.getJSON('/api/v1/weltoks.json', (response) => { this.setState({ weltoks: response }) });
    },



    handleSubmit(weltok) {
        var newState = this.state.weltoks.concat(weltok);
        this.setState({ weltoks: newState })
    },


    handleDelete(id) {
        $.ajax({
            url: `/api/v1/weltoks/${id}`,
            type: 'DELETE',
            success:() => {
               this.removeWeltokClient(id);
            }
        });
    },

    removeWeltokClient(id) {
        var newWeltoks = this.state.weltoks.filter((weltok) => {
            return weltok.id != id;
        });

        this.setState({ weltoks: newWeltoks });
    },



    handleUpdate(weltok) {
        $.ajax({
                url: `/api/v1/weltoks/${weltok.id}`,
                type: 'PUT',
                data: { weltok: weltok },
                success: () => {
                    this.updateWeltoks(weltok);

                }
            }
        )},

    updateWeltoks(weltok) {
        var weltoks = this.state.weltoks.filter((i) => { return i.id != weltok.id });
        weltoks.push(weltok);

        this.setState({weltoks: weltoks });
    },


    render() {
        return (
            <div>
                <NewWeltok handleSubmit={this.handleSubmit}/>
                <AllWeltoks  weltoks={this.state.weltoks}  handleDelete={this.handleDelete} onUpdate={this.handleUpdate}/>
            </div>
        )
    }
});

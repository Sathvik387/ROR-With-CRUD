var Header = React.createClass({
    render() {
        return (
            <div>
                <h1>Hello, World!</h1>
            </div>
        )
    }
});
var NewWeltok= React.createClass({
    handleClick() {
        var title    = this.refs.title.value;
        var description = this.refs.description.value;
	var author = this.refs.author.value;
	var tags = this.refs.tags.value;
        $.ajax({
            url: '/api/v1/weltoks',
            type: 'POST',
            data: { weltok: { title: title, description: description, author: author, tags: tags } },
            success: (weltok) => {
                this.props.handleSubmit(weltok);
            }
        });
    },
    render() {
        return (
                <div>
                    <input ref='title' placeholder='Enter the title' />
                    <input ref='description' placeholder='Enter a description' />
		    <input ref='description' placeholder='Enter author' />
		    <input ref='description' placeholder='Enter tags' />
                    <button onClick={this.handleClick}>Submit</button>
                </div>

        )
    }
});

var AllWeltoks = React.createClass({
    handleDelete(id) {
        this.props.handleDelete(id);
    },

    onUpdate(weltok) {
        this.props.onUpdate(weltok);
    },

    render() {
            var weltoks= this.props.weltoks.map((weltok) => {
                return (
                    <div key={weltok.id}>
                        <Weltok weltok={weltok}
                              handleDelete={this.handleDelete.bind(this, weltok.id)}
                              handleUpdate={this.onUpdate}/>
                    </div>
                )
            });

        return(
            <div>
                {weltoks}
            </div>
        )
    }
});

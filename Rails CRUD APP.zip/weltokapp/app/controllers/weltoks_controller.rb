class WeltoksController < ApplicationController
  before_action :set_weltok, only: [:show, :edit, :update, :destroy]

  respond_to :html

  def index
    @weltoks = Weltok.all
    respond_with(@weltoks)
  end

  def show
    respond_with(@weltok)
  end

  def new
    @weltok = Weltok.new
    respond_with(@weltok)
  end

  def edit
  end

  def create
    @weltok = Weltok.new(weltok_params)
    @weltok.save
    respond_with(@weltok)
  end

  def update
    @weltok.update(weltok_params)
    respond_with(@weltok)
  end

  def destroy
    @weltok.destroy
    respond_with(@weltok)
  end

  private
    def set_weltok
      @weltok = Weltok.find(params[:id])
    end

    def weltok_params
      params[:weltok]
    end
end

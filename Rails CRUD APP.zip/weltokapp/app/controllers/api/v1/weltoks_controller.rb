class Api::V1::WeltoksController < Api::V1::BaseController
  def index
    respond_with Weltok.all
  end

  def create
    respond_with :api, :v1, Weltok.create(weltok_params)
  end

  def destroy
    respond_with Weltok.destroy(params[:id])
  end

  def update
    weltok = Weltok.find(params["id"])
    weltok.update_attributes(weltok_params)
    respond_with weltok, json: weltok
  end

  private

  def weltok_params
    params.require(:weltok).permit(:id, :title, :description, :author, :tags)
  end
end

class Weltok < ActiveRecord::Base
end

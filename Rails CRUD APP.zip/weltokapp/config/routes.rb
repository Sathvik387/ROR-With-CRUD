Rails.application.routes.draw do
  root to: 'weltoks#index'
    namespace :api do
      namespace :v1 do
        resources :weltoks, only: [:index, :create, :destroy, :update]
      end
    end
  end

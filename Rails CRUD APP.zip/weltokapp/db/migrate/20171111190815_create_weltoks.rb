class CreateWeltoks < ActiveRecord::Migration
  def change
    create_table :weltoks do |t|
      t.text :title
      t.text :description
      t.text :author
      t.text :tags

      t.timestamps null: false
    end
  end
end
